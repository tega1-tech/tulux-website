# Tulux Website

A responsive one-page website for Tulux Interiors and Finishings, with three service divisions:
- Interiors & Finishings
- AI & Digital Solutions
- Aerial & Drone Services

## Run locally
Open `index.html` in a browser. The Google Fonts and Unsplash images require an internet connection.

## Publish on Vercel
1. Extract the ZIP.
2. Create a GitHub repository and upload `index.html` (and this README if desired).
3. In Vercel, choose **Add New → Project**, import the repository, and deploy.
4. Framework preset: **Other**. No build command is needed; the root directory contains `index.html`.
5. Connect your own domain in Vercel project settings if you have one.

Alternatively, use Vercel's CLI from this folder:
`vercel`

## Before publishing
- Replace illustrative Unsplash images with Tulux's own work when available.
- Verify the Instagram profile URL.
- Confirm the registered company name, registration number, address, phone and email are accurate.
- The contact form opens WhatsApp with a pre-filled message; it does not store submissions.
- Drone services are presented as subject to aircraft capability and required approvals. Update this wording as your actual operations and authorizations are confirmed.
- This is a static site. It does not yet include a CMS, database, analytics, online payments, or an AI chatbot.
